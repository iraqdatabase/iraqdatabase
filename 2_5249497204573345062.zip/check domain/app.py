import requests
import termcolor
from re import findall
import os


command = 'clear'
if os.name in ('nt', 'dos'):  # If Machine is running on Windows, use cls
    command = 'cls'
os.system(command)

class Check:
    def __init__(self):
        self.done = 0
        self.bad = 0
        self.checked = 0
        print(termcolor.colored("""
          ____                        _          ____ _               _           
         |  _ \  ___  _ __ ___   __ _(_)_ __    / ___| |__   ___  ___| | ___ _ __ 
         | | | |/ _ \| '_ ` _ \ / _` | | '_ \  | |   | '_ \ / _ \/ __| |/ _ \ '__|
         | |_| | (_) | | | | | | (_| | | | | | | |___| | | |  __/ (__| |  __/ |   
         |____/ \___/|_| |_| |_|\__,_|_|_| |_|  \____|_| |_|\___|\___|_|\___|_|   

        """, "yellow"))


    def check(self):
        for self.i in open("list.txt", "r").read().splitlines():
            url = "https://my.freenom.com/includes/domains/fn-available.php"
            data = {
                    'domain': self.i,
                    'tld': '',
            }
            headers = {
                    'Accept': '*/*',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Accept-Language': 'en-US,en;q=0.9,ar;q=0.8',
                    'Connection': 'keep-alive',
                    'Content-Length': '18',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Cookie': '_ga=GA1.2.1773535036.1644933097; _gid=GA1.2.1798363078.1644933097; mydottk_languagenr=0; dottyLn=en; wwwLn=en; WHMCSZH5eHTGhfvzP=0d33bag517vh3deqi0481shjl2',
                    'Host': 'my.freenom.com',
                    'Origin': 'https://www.freenom.com',
                    'Referer': 'https://www.freenom.com/',
                    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
                    'sec-ch-ua-mobile': '?0',
                    'sec-ch-ua-platform': '"Windows"',
                    'Sec-Fetch-Dest': 'empty',
                    'Sec-Fetch-Mode': 'cors',
                    'Sec-Fetch-Site': 'same-site',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36',
            }

            response = requests.post(url,data=data,headers=headers)
            check_available = findall(f'''"status":"AVAILABLE","domain":"{self.i}","tld":"(.*?)"''', response.text)
            check_unavailable = findall(f'''"status":"NOT AVAILABLE","domain":"{self.i}","tld":"(.*?)"''', response.text)
            self.done += len(check_available)
            self.bad += len(check_unavailable)
            self.checked +=1
            for i in range(10000):
                try:
                    self.save_domain = check_available[int(i)]
                    with open('# Vaild.txt', 'a') as self.file:
                        self.file.write(self.i+self.save_domain + '\n')
                except:
                    pass
            print(termcolor.colored(f'\r                            Checked: {self.checked} | Hits: {self.done} | Bad: {self.bad}', "yellow"), end='')
Check().check()